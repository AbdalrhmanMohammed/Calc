#include <iostream>
#include <conio.h>
#include <sys/stat.h>
#include <cmath>
using namespace std;

// [ Helpers
inline bool file_exists (const std::string& name) {
  struct stat buffer;   
  return (stat (name.c_str(), &buffer) == 0); 
}

int digit(char n) {
  return n - 48;
}

bool is_digit(char n) {
  return n > 47 && n < 58;
}
// Helpers ]

struct ds {
  bool done = false;
  bool value = false;
};

struct dn {
  bool done = false;
  double long value = 0;
};

string src;
unsigned long long int i = 0;

void info () {
  cout  << "Information:\n"
        << "  Application: Calculator\n"
        << "  Version: 1.0\n"
        << "  PL: C++\n\n"

        << "  Developed by: Abdalrhman Mohammed\n"
        << "  GitHub: @AbdalrhmanMohammed\n";
}

bool skip_space() {
  while (src[i++] == ' ');
  return src[--i - 1] == ' ';
}

bool positive() {
  return src[i] == '+' && src[i + 1] != '+';
}

bool negative() {
  return src[i] == '-' && src[i + 1] != '-';
}

bool incre() {
  return src[i] == '+' && src[i + 1] == '+';
}

bool decre() {
  return src[i] == '-' && src[i + 1] == '-';
}

ds get_sign() {
  skip_space();

  ds data;

  data.done = (data.value = negative()) || positive();

  while (data.done) {
    i++;

    skip_space();

    if (negative()) {
      data.value = !data.value;
    } else if (!positive()) {
      break;
    }
  }

  return data;
}

dn get_numb() {
  dn data;
  unsigned long int unit = 1;

  data.value = (data.done = is_digit(src[i]))? digit(src[i]): 0;

  while (data.done) {
    i++;

    if (!is_digit(src[i])) {
      break;
    }

    data.value = data.value * 10 + digit(src[i]);
  }

  if (src[i] == '.') {
    while (is_digit(src[1 + i])) {
      data.value = data.value * 10 + digit(src[1 + i++]);
      data.value != 0 && (unit *= 10);
    }

    if (unit != 1) {
      i++;
      data.value /= unit;
      data.done = true;
    } else {
      if (data.done) {
        i++;
      }
    }
  }

  return data;
}

char get_oper() {
  return (
    src[i] == '*'?

      (src[++i] == '*')?

        (++i, 'E'): 'U'

    : src[i] == '/'?
        (++i, 'D')

    : src[i] == '%'?
      (++i, 'O'): '\0'
  );
}

void calc() {
  i = 0;

  src.clear();

  getline(cin, src);

  // cout << "\n";

  skip_space();

  char oper;
  dn numb1, numb2;
  ds sign1, sign2;
  double long result;

  sign1 = get_sign();

  numb1 = get_numb();

  if (!numb1.done) {

    if (incre()) {
      cout << "SyntaxError: pre increment is not allowed\nIndex: " << i;
    } else if (decre()) {
      cout << "SyntaxError: pre decrement is not allowed\nIndex: " << i;
    } else {
      cout << "SyntaxError: expected number\nIndex: " << i;
    }
  } else {
    if (sign1.value) {
      numb1.value *= -1;
    }

    skip_space();

    if (src[i] == '\0') {
      cout << "Result: " << numb1.value;
    } else {
      oper = get_oper();

      sign2 = get_sign();

      if (oper != '\0' || sign2.done) {
        numb2 = get_numb();
      }

      if (numb2.done) {

        if (sign2.value) {
          numb2.value *= -1;
        }

        skip_space();

        if (src[i] == '\0') {
          if (oper == 'U') {
            result = numb1.value * numb2.value;
          } else if (oper == 'E') {
            result = pow(numb1.value, numb2.value);
          } else if (oper == 'D') {
            result = numb1.value / numb2.value;
          } else if (oper == 'O') {
            result = remainder(numb1.value, numb2.value);
          } else {
            result = numb1.value + numb2.value;
          }

          cout << "Result: " << result;
        } else {
          cout << "SyntaxError: unexpected '" << src[i] << "' Wipe it and beyond\nIndex: " << i;
        }
      } else {

        if (incre()) {
          cout << "SyntaxError: pre increment is not allowed\nIndex: " << i;
        } else if (decre()) {
          cout << "SyntaxError: pre decrement is not allowed\nIndex: " << i;
        } else if (!(oper || sign2.done)) {
          cout << "SyntaxError: expected operator instead of '" << src[i] << "'\nIndex: " << i;
        } else if (src[i]) {
          cout << "A SyntaxError: expected number instead of '" << src[i] << "'\nIndex: " << i;
        } else {
          cout << "SyntaxError: expected number\nIndex: " << i;
        }
      }
    }
  }

  cout << "\n";
}

// RUN
int main () {
  info();

  if (!file_exists("calc-github@AbdalrhmanMohammed.exe")) {
    cout  << "\n-----------------------------------\n\n"

          << "Warning:\n"
          << "  Do not try to change the file name\n"
          << "  Rename the app file to 'calc-github@AbdalrhmanMohammed' so you can use it\n\n"

          << "Press any key to exit ...\n";

    char ch = getch();

    return 1;
  }

  

  cout  << "\nInstructions:\n"
        << "  Allowed only two numbers to calculate\n"
        << "  Allowed operating parameters: ( +  -  *  / % ** )\n"
        << "  Allowed decimal numbers: examples ( 0.0  0.  .0 )\n"

        << "\n----------------------------------------------------------\n\n";

  string commend, valid;

  while (true) {

    cout << "calc: ";
    calc();
    cout << "\n";
  }
}
